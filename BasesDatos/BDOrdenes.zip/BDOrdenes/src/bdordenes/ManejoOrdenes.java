/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bdordenes;

/**
 *
 * @author jel_1
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.*;
import java.util.Properties;

public class ManejoOrdenes {
    // Datos de conexión a la base de datos
    //static final String JDBC_URL = "jdbc:mysql://localhost:3306/test";
    //static final String USUARIO = "root";
    //static final String PASSWORD = "tripo17";

    public static void main(String[] args) throws IOException {
        Connection conexion = null;
        try {
            //conexion = DriverManager.getConnection(JDBC_URL, USUARIO, PASSWORD);
            Properties propiedades = cargarConfiguracion();
            conexion = DriverManager.getConnection(propiedades.getProperty("db.jdbc_url"),
                                                     propiedades.getProperty("db.usuario"),
                                                     propiedades.getProperty("db.contrasena"));
            Scanner scanner = new Scanner(System.in);
            int opcion;
            do {
                mostrarMenu();
                System.out.print("Opcion: ");
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea después de leer el entero
                
                switch (opcion) {
                    case 1:
                        seleccionarRegistros(conexion);
                        break;
                    case 2:
                        System.out.println("Ingrese el nombre del cliente:");
                        String cliente = scanner.nextLine();
                        System.out.println("Ingrese el monto:");
                        double monto = scanner.nextDouble();
                        insertarRegistro(conexion, cliente, monto);
                        break;
                    case 3:
                        System.out.println("Ingrese el ID del registro a actualizar:");
                        int idActualizar = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea después de leer el entero
                        System.out.println("Ingrese el nuevo nombre del cliente:");
                        String nuevoCliente = scanner.nextLine();
                        System.out.println("Ingrese el nuevo monto:");
                        double nuevoMonto = scanner.nextDouble();
                        actualizarRegistro(conexion, idActualizar, nuevoCliente, nuevoMonto);
                        break;
                    case 4:
                        System.out.println("Ingrese el ID del registro a borrar:");
                        int idBorrar = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea después de leer el entero
                        borrarRegistro(conexion, idBorrar);
                        break;
                    case 5:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, seleccione una opción del menú.");
                }
            } while (opcion != 5);

        } catch (SQLException e) {
            System.err.println("SQL exception: " + e.getMessage());
            System.exit(1); 
        } finally {
            if (conexion != null) {
                try {
                    conexion.close();
                } catch (SQLException e) {
                    System.err.println("SQL exception: " + e.getMessage());
                    System.exit(1); 
                }
            }
        }
    }
    
    public static Properties cargarConfiguracion() throws IOException {
        Properties propiedades = new Properties();
        try{
            FileInputStream archivoConfig = new FileInputStream("./src/bdordenes/config.properties");
            propiedades.load(archivoConfig);
        }catch(FileNotFoundException e){
            System.err.println("SQL exception: " + e.getMessage());
        }
        return propiedades;
    }
    
    public static void mostrarMenu() {
        System.out.println("Seleccione una opción:");
        System.out.println("1. Seleccionar registros");
        System.out.println("2. Insertar un nuevo registro");
        System.out.println("3. Actualizar un registro existente");
        System.out.println("4. Borrar un registro");
        System.out.println("5. Salir");
    }

    // Función para seleccionar registros
    public static void seleccionarRegistros(Connection conexion) throws SQLException {
        Statement statement = conexion.createStatement();
        var resultado = statement.executeQuery("SELECT * FROM ordenes");
        while (resultado.next()) {
            System.out.println("ID: " + resultado.getInt("id") +
                    ", Cliente: " + resultado.getString("cliente") +
                    ", Monto: " + resultado.getDouble("monto"));
        }
        resultado.close();
        statement.close();
    }

    // Función para insertar un nuevo registro
    public static void insertarRegistro(Connection conexion, String cliente, double monto) throws SQLException {
        PreparedStatement preparedStatement = conexion.prepareStatement("INSERT INTO ordenes (cliente, monto) VALUES (?, ?)");
        preparedStatement.setString(1, cliente);
        preparedStatement.setDouble(2, monto);
        preparedStatement.executeUpdate();
        preparedStatement.close();
        System.out.println("Nuevo registro insertado.");
    }

    // Función para actualizar un registro existente
    public static void actualizarRegistro(Connection conexion, int id, String nuevoCliente, double nuevoMonto) throws SQLException {
        PreparedStatement preparedStatement = conexion.prepareStatement("UPDATE ordenes SET cliente = ?, monto = ? WHERE id = ?");
        preparedStatement.setString(1, nuevoCliente);
        preparedStatement.setDouble(2, nuevoMonto);
        preparedStatement.setInt(3, id);
        int filasActualizadas = preparedStatement.executeUpdate();
        if (filasActualizadas > 0) {
            System.out.println("Registro actualizado correctamente.");
        } else {
            System.out.println("No se encontró ningún registro con el ID especificado.");
        }
        preparedStatement.close();
    }

    // Función para borrar un registro
    public static void borrarRegistro(Connection conexion, int id) throws SQLException {
        PreparedStatement preparedStatement = conexion.prepareStatement("DELETE FROM ordenes WHERE id = ?");
        preparedStatement.setInt(1, id);
        int filasBorradas = preparedStatement.executeUpdate();
        if (filasBorradas > 0) {
            System.out.println("Registro borrado correctamente.");
        } else {
            System.out.println("No se encontró ningún registro con el ID especificado.");
        }
        preparedStatement.close();
    }
}
