/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bdordenes;

/**
 *
 * @author jel_1
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.math.BigDecimal;

public class BDOrdenes {
    // JDBC URL, username y password de tu base de datos MySQL
    static final String JDBC_URL = "jdbc:mysql://localhost:3306/test";
    static final String USERNAME = "root";
    static final String PASSWORD = "tripo17";

    public static void main(String[] args) {
        // Sentencia SQL para seleccionar datos de la tabla
        String sql = "SELECT * FROM ordenes";

        try (
            // Establecer conexión con la base de datos
            Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            
            // Crear una declaración para ejecutar la consulta
            Statement statement = conn.createStatement();
            
            // Ejecutar la consulta y obtener el resultado
            ResultSet resultSet = statement.executeQuery(sql)
        ) {
            // Iterar sobre el resultado y mostrar los datos
            while (resultSet.next()) {
                // Obtener los valores de cada columna por nombre o índice
                int columna1 = resultSet.getInt("id");
                String columna2 = resultSet.getString("cliente");
                BigDecimal columna3 = resultSet.getBigDecimal("monto");
                // ... obtén los valores de las otras columnas según sea necesario
                
                // Mostrar los datos
                System.out.println("id: " + columna1 + ", cliente: " + columna2 + ", monto: " + columna3);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

